//import JsonData from './../JsonData/BookDetails.json';

function getAllData() {
    return fetch('/JsonData/BookDetails.json', { method: 'GET' })
        .then(out => out.json())
        .then(out => { return out; });
}

export default getAllData;