import React from "react";
import "./App.css";
import AppRoute from "./Routing/routes";

const App = () => {
  return (
    <>
      <AppRoute />
    </>
  );
};

export default App;
